import { BrowserProvider, Contract, formatUnits, parseUnits } from '/ethers.js';

const element = id => document.getElementById(id);
const account = element('account');
const status = element('status');
const buttons = ['claim', 'refresh', 'lock', 'unlock'].map(element);
let info;
let requestId = 0;

const provider = new BrowserProvider({
  async request({ method, params }) {
    const response = await fetch('/rpc', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jsonrpc: '2.0', id: ++requestId, method, params }),
    });
    const { result, error } = await response.json();
    if (error) throw Object.assign(new Error(error.message), error);
    return result;
  },
});
provider.pollingInterval = 500;

async function contracts() {
  const signer = await provider.getSigner(account.value);
  return {
    token: new Contract(info.tokenAddress, info.tokenAbi, signer),
    vault: new Contract(info.vaultAddress, info.vaultAbi, signer),
  };
}

async function refresh({ token, vault }) {
  const [balance, position] = await Promise.all([token.balanceOf(account.value), vault.myPosition()]);
  element('balance').textContent = `${formatUnits(balance)} VDT`;
  element('locked').textContent = `${formatUnits(position.amount)} VDT`;
  element('deadline').textContent = position.amount
    ? new Date(Number(position.unlockAt) * 1000).toLocaleString() : 'No active position';
  element('reward').textContent = `${formatUnits(position.calculatedReward)} VDT`;
}

async function run(action, success) {
  account.disabled = true;
  for (const button of buttons) button.disabled = true;
  status.textContent = 'Working…';
  try {
    const connected = await contracts();
    await action(connected);
    await refresh(connected);
    status.textContent = success;
  } catch (error) {
    status.textContent = error.revert?.name || error.shortMessage || error.message;
  } finally {
    account.disabled = false;
    for (const button of buttons) button.disabled = false;
  }
}

const showAccount = () => run(async () => {}, 'Account updated.');
account.addEventListener('change', showAccount);
element('refresh').addEventListener('click', showAccount);
element('claim').addEventListener('click', () => run(async ({ token }) => {
  await (await token.claim()).wait();
}, 'Demo tokens claimed.'));
element('lock-form').addEventListener('submit', event => {
  event.preventDefault();
  run(async ({ token, vault }) => {
    const amount = parseUnits(element('amount').value.trim());
    const duration = Number(element('duration').value);
    if (amount <= 0n) throw new Error('Enter an amount greater than zero.');
    if ((await vault.myPosition()).amount) throw new Error('Unlock your existing position first.');
    if (await token.balanceOf(account.value) < amount) throw new Error('Insufficient demo tokens.');
    await (await token.approve(info.vaultAddress, amount)).wait();
    await (await vault.lock(amount, duration)).wait();
  }, 'Tokens locked.');
});
element('unlock').addEventListener('click', () => run(async ({ vault }) => {
  const { amount, unlockAt } = await vault.myPosition();
  if (!amount) throw new Error('No active position.');
  if (BigInt(Math.floor(Date.now() / 1000)) < unlockAt) {
    throw new Error(`Tokens are locked until ${new Date(Number(unlockAt) * 1000).toLocaleString()}.`);
  }
  await (await vault.unlock()).wait();
}, 'Locked tokens returned.'));

async function initialize() {
  const response = await fetch('/deployment.json');
  if (!response.ok) throw new Error('Demo deployment could not be loaded.');
  info = await response.json();
  const addresses = await provider.send('eth_accounts', []);
  addresses.forEach((address, index) => account.add(new Option(`Account ${index + 1} · ${address}`, address)));
  await showAccount();
}

initialize().catch(error => { status.textContent = error.message; });
