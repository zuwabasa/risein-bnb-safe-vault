const { before, beforeEach, afterEach, test } = require('node:test');
const assert = require('node:assert/strict');
const ganache = require('ganache');
const memdown = require('memdown');
const { ethers } = require('ethers');
const { compile } = require('../scripts/compile.cjs');

const day = 86400;
const amount = ethers.parseUnits('100');
const initial = ethers.parseUnits('1000');
let artifacts, rpc, provider, token, vault, alice, bob, vaultAddress;

before(() => { artifacts = compile(); });

async function deploy(name, ...args) {
  const { abi, bytecode } = artifacts[name];
  const instance = await new ethers.ContractFactory(abi, bytecode, alice).deploy(...args);
  await instance.waitForDeployment();
  return instance;
}

async function send(transaction) {
  return (await transaction).wait();
}

async function lock(signer, units, duration) {
  await send(token.connect(signer).approve(vaultAddress, units));
  return send(vault.connect(signer).lock(units, duration));
}

async function advance(seconds) {
  await rpc.request({ method: 'evm_increaseTime', params: [seconds] });
  await rpc.request({ method: 'evm_mine', params: [] });
}

beforeEach(async () => {
  rpc = ganache.provider({
    chain: { hardfork: 'shanghai' }, database: { db: memdown() }, logging: { quiet: true },
  });
  provider = new ethers.BrowserProvider(rpc);
  [alice, bob] = await Promise.all([provider.getSigner(0), provider.getSigner(1)]);
  token = await deploy('DemoToken');
  vault = await deploy('SafeVault', await token.getAddress());
  vaultAddress = await vault.getAddress();
  await send(token.connect(alice).claim());
  await send(token.connect(bob).claim());
});

afterEach(async () => {
  await provider.destroy();
  await rpc.disconnect();
});

test('locks tokens and records a caller-specific position and event', async () => {
  const receipt = await lock(alice, amount, day);
  const position = await vault.connect(alice).myPosition();
  assert.equal(position.amount, amount);
  assert.equal(position.unlockAt - position.lockedAt, BigInt(day));
  assert.equal(await token.balanceOf(alice.address), initial - amount);
  assert.equal(await token.balanceOf(vaultAddress), amount);
  const log = receipt.logs.find(entry => entry.address === vaultAddress);
  const event = vault.interface.parseLog(log);
  assert.equal(event.name, 'TokensLocked');
  assert.equal(event.args.owner, alice.address);
});

test('validates token, amount, duration and duplicate positions', async () => {
  await assert.rejects(deploy('SafeVault', alice.address));
  await assert.rejects(vault.lock.staticCall(0, day), /InvalidAmount/);
  await assert.rejects(vault.lock.staticCall(amount, 0), /InvalidDuration/);
  await assert.rejects(vault.lock.staticCall(amount, day * 365 + 1), /InvalidDuration/);
  await lock(alice, amount, day);
  await assert.rejects(vault.lock.staticCall(amount, day), /PositionExists/);
});

test('failed transfer leaves the position and balances unchanged', async () => {
  await assert.rejects(async () => {
    await send(vault.lock(amount, day, { gasLimit: 300000 }));
  }, /revert/i);
  assert.equal((await vault.myPosition()).amount, 0n);
  assert.equal(await token.balanceOf(vaultAddress), 0n);
  assert.equal(await token.balanceOf(alice.address), initial);
});

test('separates positions and rejects early and unauthorized withdrawals', async () => {
  await lock(alice, amount, day);
  assert.equal((await vault.connect(bob).myPosition()).amount, 0n);
  await assert.rejects(vault.connect(bob).unlock.staticCall(), /NoPosition/);
  await lock(bob, amount * 2n, day * 2);
  await assert.rejects(vault.unlock.staticCall(), /StillLocked/);
  await advance(day + 1);
  await send(vault.unlock());
  await assert.rejects(vault.connect(bob).unlock.staticCall(), /StillLocked/);
  assert.equal(await token.balanceOf(vaultAddress), amount * 2n);
  assert.equal((await vault.connect(bob).myPosition()).amount, amount * 2n);
});

test('accrues reward by elapsed time and caps it at maturity', async () => {
  await lock(alice, amount, day * 365);
  await advance(day * 90);
  const quarter = (await vault.myPosition()).calculatedReward;
  const expected = amount * 90n * 500n / (365n * 10_000n);
  const oneMinuteReward = amount * 60n * 500n / (BigInt(day * 365) * 10_000n);
  assert.ok(quarter >= expected && quarter <= expected + oneMinuteReward);
  await advance(day * 366);
  assert.equal((await vault.myPosition()).calculatedReward, ethers.parseUnits('5'));
});

test('returns principal only, emits the calculated reward and permits another lock', async () => {
  await lock(alice, amount, day);
  await advance(day + 1);
  const receipt = await send(vault.unlock());
  assert.equal(await token.balanceOf(alice.address), initial);
  assert.equal(await token.balanceOf(vaultAddress), 0n);
  assert.equal((await vault.myPosition()).calculatedReward, 0n);
  const event = vault.interface.parseLog(receipt.logs.find(entry => entry.address === vaultAddress));
  assert.equal(event.name, 'TokensUnlocked');
  assert.equal(event.args.calculatedReward, amount * 500n / (365n * 10_000n));
  await assert.rejects(vault.unlock.staticCall(), /NoPosition/);
  await lock(alice, amount, day);
  assert.equal((await vault.myPosition()).amount, amount);
});
