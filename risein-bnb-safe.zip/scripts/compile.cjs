const fs = require('node:fs');
const path = require('node:path');
const solc = require('solc');

function compile() {
  const sources = {};
  for (const name of ['SafeVault.sol', 'DemoToken.sol']) {
    sources[name] = { content: fs.readFileSync(path.join(__dirname, '../contracts', name), 'utf8') };
  }
  const output = JSON.parse(solc.compile(JSON.stringify({
    language: 'Solidity',
    sources,
    settings: {
      evmVersion: 'shanghai',
      optimizer: { enabled: true, runs: 200 },
      outputSelection: { '*': { '*': ['abi', 'evm.bytecode.object'] } },
    },
  })));
  const errors = (output.errors || []).filter(({ severity }) => severity === 'error');
  if (errors.length) throw new Error(errors.map(({ formattedMessage }) => formattedMessage).join('\n'));
  return Object.fromEntries(['SafeVault', 'DemoToken'].map(name => {
    const { abi, evm } = output.contracts[`${name}.sol`][name];
    return [name, { abi, bytecode: `0x${evm.bytecode.object}` }];
  }));
}

if (require.main === module) {
  const contracts = compile();
  console.log(`Solidity ${solc.version()}: compiled ${Object.keys(contracts).join(', ')}`);
}

module.exports = { compile };
