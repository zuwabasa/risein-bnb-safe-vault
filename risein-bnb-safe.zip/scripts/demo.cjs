const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const ganache = require('ganache');
const memdown = require('memdown');
const { ethers } = require('ethers');
const { compile } = require('./compile.cjs');

async function start() {
  const chain = ganache.provider({
    chain: { chainId: 31337, hardfork: 'shanghai' },
    wallet: { totalAccounts: 2 },
    miner: { blockTime: 1 },
    logging: { quiet: true },
    database: { db: memdown() },
  });
  const provider = new ethers.BrowserProvider(chain);
  const signer = await provider.getSigner();
  const { SafeVault, DemoToken } = compile();
  const token = await new ethers.ContractFactory(DemoToken.abi, DemoToken.bytecode, signer).deploy();
  await token.waitForDeployment();
  const tokenAddress = await token.getAddress();
  const vault = await new ethers.ContractFactory(SafeVault.abi, SafeVault.bytecode, signer).deploy(tokenAddress);
  await vault.waitForDeployment();

  const info = JSON.stringify({
    tokenAddress, vaultAddress: await vault.getAddress(),
    tokenAbi: DemoToken.abi, vaultAbi: SafeVault.abi,
  });
  const ethersRoot = path.dirname(path.dirname(require.resolve('ethers')));
  const files = new Map([
    ['/', ['text/html', path.join(__dirname, '../web/index.html')]],
    ['/app.js', ['text/javascript', path.join(__dirname, '../web/app.js')]],
    ['/ethers.js', ['text/javascript', path.join(ethersRoot, 'dist/ethers.min.js')]],
  ]);
  const rpcMethods = new Set([
    'eth_chainId', 'eth_accounts', 'eth_blockNumber', 'eth_getBalance', 'eth_call',
    'eth_estimateGas', 'eth_sendTransaction', 'eth_getTransactionByHash', 'eth_getTransactionReceipt',
  ]);

  const server = http.createServer(async (req, res) => {
    const port = server.address().port;
    if (req.headers.host !== `127.0.0.1:${port}`) {
      res.writeHead(403).end();
      return;
    }
    if (req.method === 'GET' && req.url === '/deployment.json') {
      res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }).end(info);
      return;
    }
    if (req.method === 'POST' && req.url === '/rpc' &&
        req.headers.origin === `http://127.0.0.1:${port}` &&
        req.headers['content-type']?.startsWith('application/json')) {
      let id = null;
      try {
        let body = '';
        for await (const chunk of req) {
          body += chunk;
          if (body.length > 65536) throw new Error('Request too large');
        }
        const request = JSON.parse(body);
        id = request.id;
        if (!rpcMethods.has(request.method)) throw new Error('Unsupported demo method');
        const result = await chain.request({ method: request.method, params: request.params || [] });
        res.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({ jsonrpc: '2.0', id, result }));
      } catch (error) {
        res.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({
          jsonrpc: '2.0', id, error: { code: -32000, message: error.message, data: error.data },
        }));
      }
      return;
    }
    const file = req.method === 'GET' && files.get(req.url);
    if (!file) {
      res.writeHead(404).end();
      return;
    }
    res.writeHead(200, { 'Content-Type': file[0], 'X-Content-Type-Options': 'nosniff' });
    fs.createReadStream(file[1]).pipe(res);
  });

  const port = Number(process.env.VAULT_DEMO_PORT || 4173);
  server.listen(port, '127.0.0.1', () => console.log(`Demo at http://127.0.0.1:${server.address().port}`));
}

start().catch(error => { console.error(error); process.exitCode = 1; });
